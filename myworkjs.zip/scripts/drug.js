function DisableEnableForm(xHow){
	var wnd = top.formWindow();
	objElems = wnd.document.forms['crf'].elements;
	for(i=0;i<objElems.length;i++){
	objElems[i].disabled = xHow;
	}
}


function selectOptionBox(el_name, value, _default){
	var wnd = top.formWindow();
	var element = wnd.document.forms['crf'].elements[el_name];
	
	if(value){
		for (var i=0; i<element.length; i++){
			if(element.options[i].text == value){
				element.options[i].defaultSelected = true;
				element.options[i].selected = true;
			}
		}
	}else{
		for (var i=0; i<element.length; i++){
			if(element.options[i].text == _default){
				element.options[i].defaultSelected = true;
				element.options[i].selected = true;
			}
		}
	}
}

function selectMultipleOptionBox(el_name, values, _default){
	var wnd = top.formWindow();
	var element = wnd.document.forms['crf'].elements[el_name];
	
	if(values){
		for (var i=0; i<element.length; i++){
			if(values.indexOf(element.options[i].text)>=0){
				element.options[i].defaultSelected = true;
				element.options[i].selected = true;
			}
		}
	}else{
		for (var i=0; i<element.length; i++){
			if(element.options[i].text == _default){
				element.options[i].defaultSelected = true;
				element.options[i].selected = true;
			}
		}
	}
}

function getMainForm(){
	return document.forms['crf'];
}

function isModifiedDrug(targetForm){

	var ret = new Array();
	var checked = new Object();
	//var fQueries = top.formWindow().fQueries;

	//checkReasons();

	var elements = targetForm.elements;
	var elements_length = elements.length
	for (var i=0; i<elements_length; i++)
 	{
		if(elements[i].getAttribute("nodb") == "true") continue;
 		var fname = elements[i].name;
		var type = elements[i].type;

 		// Check only DATA-fields and only one time
 		if (inArray(ret,fname) || null!=checked[fname]){
			continue;
		}
		checked[fname] = true;

 		var el = elements[fname];
 		if (null==el)
 			continue;

		var newlyCreated = isCreated(el);		
		var hasQuery = false;

		switch (type) {
		
		case "text":
		case "textarea":
			if (el.defaultValue!=el.value) {
				ret[ret.length] = new modifiedField(fname, "test", newlyCreated, hasQuery);
			}
			break;
		
		case "radio":
		case "checkbox":
			if (null!=el.length)
			{
				for (var b=0; b<el.length; b++)
				{
					if (el[b].checked!=el[b].defaultChecked) {
						ret[ret.length] = new modifiedField(fname, getDescr(fname), newlyCreated, hasQuery);
						break;
					}
				}
			} else {
				if (el.checked!=el.defaultChecked) {
					ret[ret.length] = new modifiedField(fname, getDescr(fname), newlyCreated, hasQuery);
				}
			}
			break;

		case "select-one":

			for (var ind=0; ind<el.options.length; ind++){

				if (el.options[ind].defaultSelected && el.selectedIndex!=ind) {
					ret[ret.length] = new modifiedField(fname, getDescr(fname), newlyCreated, hasQuery);
					break;
				}
			}
	 		if (!inArray(ret,fname) && el.selectedIndex>=0 &&
	 			""!=el.options[el.selectedIndex].value && 
	 			!el.options[el.selectedIndex].defaultSelected) 
	 		{
				ret[ret.length] = new modifiedField(fname, getDescr(fname), true, hasQuery);
			}

			break;
			
		}


	}
	
	return ret;
}

function loadDrugTabRecord(id, url, opt_url, url_prefix){
	if (null==opt_url) opt_url=""; else opt_url="&"+opt_url;
	opt_url = "id="+id+opt_url;

	top.saveDrugModifications(false, null, null, opt_url,
		function() {
			var wnd = top.rightWindow(); 
			if (null!=wnd) wnd.document.body.style.cursor="wait";
			wnd.location.replace((url_prefix?url_prefix:top.urlPrefix)+url+(top.ext_url?top.ext_url:"")+"?"+opt_url);
		}
	);
	return false;
}

function loadDrugRecord(id, url, opt_url, url_prefix){
	if (null==opt_url) opt_url=""; else opt_url="&"+opt_url;
	opt_url = "id="+id+opt_url;

	top.saveDrugModifications(false, null, null, opt_url,
		function() {
			var wnd = formWindow(); if (null!=wnd) wnd.document.body.style.cursor="wait";
			if (top.rightWindow().topFrame) {
				try {
					var mwnd = top.rightWindow().topFrame();
					mwnd.modulesHeader.removeArrows();
					mwnd.modules.clear();
				} catch (e){}
			}
			wnd.location.replace((url_prefix?url_prefix:top.urlPrefix)+url+(top.ext_url?top.ext_url:"")+"?"+opt_url);
		}
	);
	top.pipeCommands=null;
	return false;
}

function setDrugMode(mode) {
	if (!top.mb_DrugMenuBar.get("view_drug").getItem(mode).isChecked()) {	
	
		var items = top.mb_DrugMenuBar.get("view_drug").getItems();
		
		for (var i=0; i<items.length; i++) {
			if (!!items[i].setCheck) {
				items[i].setCheck(false);
			}
		}			
		top.mb_DrugMenuBar.get("view_drug").getItem(mode).setCheck(true);		
		top.rightWindow().location.replace(top.urlPrefix+"right"+(top.ext_url?top.ext_url:"")+"?mode="+mode+"&ts="+getTimeStamp());				
		top.setTimeout(function () {top.leftWindow().location.replace(top.urlPrefix+"left"+(top.ext_url?top.ext_url:"")+"?mode="+mode+"&ts="+getTimeStamp());	}, 100);
	}
}

function setLeftSide(mode) {
	if (!top.mb_DrugMenuBar.get("view_drug").getItem(mode).isChecked()) {
		var items = top.mb_DrugMenuBar.get("view_drug").getItems();
		
		for (var i=0; i<items.length; i++) {
			if (!!items[i].setCheck) {
				items[i].setCheck(false);
			}
		}			
		top.mb_DrugMenuBar.get("view_drug").getItem(mode).setCheck(true);			
		top.leftWindow().location.replace(top.urlPrefix+"left"+(top.ext_url?top.ext_url:"")+"?mode="+mode+"&ts="+getTimeStamp());		
	}
}

function changeViewAndSave(mode, cmd) {
	if (!top.mb_DrugMenuBar.get("view_drug").getItem(mode).isChecked()) {
		var items = top.mb_DrugMenuBar.get("view_drug").getItems();
		
		for (var i=0; i<items.length; i++) {
			if (items[i].id == "initsite" && items[i].isChecked()) cmd = "operation=SiteStatusChange";
			if (items[i].id == "orders" && items[i].isChecked()) cmd = "operation=Order";
			if (items[i].id == "batches" && items[i].isChecked()) cmd = "operation=Batch";
		}
		//alert(cmd);
		opt_url = "mode="+mode+(cmd?"&"+cmd:"")+"&ts="+getTimeStamp();
		//var url = containersUrl[rightWindow().mode]
		var url = null;
		top.saveDrugModifications(false, url, "top.setDrugMode('"+mode+"')", opt_url,
			function() {
				top.setDrugMode(mode);
			}
		);
	}
}

function checkDrugViewItem(view) {
	var viewMenu = top.mb_DrugMenuBar.get("view_drug");
	for (var i=0; i<viewMenu.size(); i++) {
		var menuItem = viewMenu.getItem(i);
		if (!!menuItem && !!menuItem.setCheck && typeof menuItem.setCheck == "function") {
			menuItem.setCheck(view==menuItem.id);
		}
	}
}
	
function updateTableOrder(tableId, column_name, pages_show, page_items_per_page, command_callback, command_url, column_mapping, avoid_switch) {
	var tbl = document.getElementById(tableId);	
	var columns = tbl.getElementsByTagName("th");
	
	for (var i = 0; i < columns.length; i++) {
		if (avoid_switch !== true) {
			if (columns[i].innerHTML === column_name) {
				if (columns[i].className !== "asc") {
					columns[i].className = "asc";
					columns[i].style.background = 'grey url("../images/ft-headup.gif") top right no-repeat';
					columns[i].style.cursor = "pointer";				
				} else {
					columns[i].className = "desc";
					columns[i].style.background = 'grey url("../images/ft-headdown.gif") top right no-repeat';
					columns[i].style.cursor = "pointer";				
				}
			} else {
				columns[i].className = "desc";
				columns[i].style.background = 'grey url("../images/ft-head.gif") top right no-repeat';	
				columns[i].style.cursor = "pointer";			
			}
		}
		if (column_mapping[columns[i].innerHTML] !== undefined) {
			columns[i].onclick = function () {
				updateTableOrder(tableId, this.innerHTML, pages_show, page_items_per_page, command_callback, command_url, column_mapping);
				clickTablePaging(tableId, 1, page_items_per_page, command_callback, command_url, column_mapping);
				updateTablePaging(tableId, 1, pages_show);
			};
		} else {
			columns[i].onclick = "";
			columns[i].onmouseover = "";
			columns[i].onmouseout = "";
			columns[i].style.cursor = "default";
		}
	}	
}

function readDataset(node) {
	if (node.dataset) {
		return node.dataset;
	} else { 	
		var dataset = {};
		for (var i = 0; i < node.attributes.length; i++) {
			var attr = node.attributes[i];
			var name = attr.name.replace("__", " ").split("-");		
			if (attr.specified && name[0] === 'data') {
				if (name.length > 2) {
					if (dataset[name[1]] === undefined) {
						dataset[name[1]] = {};
					}
					dataset[name[1]][name[2]] = attr.value;
				} else {
					dataset[name[1]] = attr.value;
				}
			}
		}		
		return dataset;
	}
}

function writeDataset(node, object) {
	if (node.dataset) {
		for (var key in object) {
			if (object.hasOwnProperty(key)) {
				if (object[key] instanceof Object && JSON.stringify) { 
					node.dataset[key] = JSON.stringify(object[key]);
				} else {
					node.dataset[key] = object[key];
				}
			}
		}
	} else {	
		for (var key in object) {
			if (object.hasOwnProperty(key)) {
				if (object[key] instanceof Object) {
					for (var subkey in object[key]) {
						var attrib = "data-" + key + '-' + subkey.replace(" ", "__");
						node.setAttribute(attrib, object[key][subkey]);									
					}
				} else {
					node.setAttribute("data-" + key, object[key]);				
				} 
			}
		}
	}
}

function classSelector(node, cn) {
	if (node === null || node === undefined) {
		return [];
	}
	
	if (document.getElementsByClassName) {
		return node.getElementsByClassName(cn);	
	}

	var indexOf = [].indexOf || function(prop) {
		for (var i = 0; i < this.length; i++) {
			if (this[i] === prop) return i;
		}
		return -1;
	};

	var elems = document.querySelectorAll ? node.querySelectorAll('.' + cn) : (function() {
		var all = node.getElementsByTagName("*"),
			elements = [],
			i = 0;
		for (; i < all.length; i++) {
			if (all[i].className && (" " + all[i].className + " ").indexOf(" " + cn + " ") > -1 && indexOf.call(elements,all[i]) === -1) elements.push(all[i]);
		}
		return elements;
	})();

	return elems;
}

function createTablePaging(tableId, command_callback, scope, page_current, page_items_per_page, items_total, pages_show, column_name, column_mapping, avoid_switch){
	
	if (column_mapping[column_name] === undefined) {
		column_name = "";
	}	
	
	top.formWindow()[command_callback](tableId, new Array());
	
	var command_url = top.urlPrefix + "commands/paging?scope="+scope;

	var tblPaging = document.createElement("div");
	
	writeDataset(tblPaging, {	
		"table_id": tableId,
		"command_callback": command_callback,
		"scope": scope,
		"page_current": page_current,
		"page_items_per_page": page_items_per_page,
		"items_total": items_total,
		"pages_show": pages_show,
		"column_name": column_name,
		"column_mapping": column_mapping
	});	

	tblPaging.id = "paging" + tableId;
	tblPaging.style.padding = "10px 0 0 0";
	tblPaging.style.textAlign = "center";
	
	var divItemsPerPage = document.createElement("div");
	
	divItemsPerPage.style.textAlign = "center";	
	divItemsPerPage.style.display = "inline-block";
	divItemsPerPage.style.cssFloat = "left";
	
	var textItemsPerPage = document.createElement("div");
		
	textItemsPerPage.innerHTML = "List size";
	textItemsPerPage.style.fontSize = "10px";
	
	var inputItemsPerPage = document.createElement("input");
	
	inputItemsPerPage.type = "text";
	inputItemsPerPage.size = 2;	
	inputItemsPerPage.maxLength = 3;
	inputItemsPerPage.value = page_items_per_page;
	inputItemsPerPage.style.textAlign = "center";		
	inputItemsPerPage.onkeypress = function(e) {
		e = e || window.event;
		var code = (e.keyCode ? e.keyCode : e.which);
		if (code == 13 && +this.value > 0) {
			var tbl = document.getElementById(tableId);
			var dataset = readDataset(tblPaging);
			var value = +this.value;
			var map = (tblPaging.dataset && JSON.parse) ? JSON.parse(dataset.column_mapping) : dataset.column_mapping;
			tbl.parentNode.removeChild(tblPaging);
			tbl.parentNode.removeChild(divItemsPerPage);
			createTablePaging(dataset.table_id, dataset.command_callback, dataset.scope, 1,
							  value, +dataset.items_total, +dataset.pages_show, column_name, map, true);
		}		
	}
	divItemsPerPage.appendChild(textItemsPerPage);	
	divItemsPerPage.appendChild(inputItemsPerPage);
		
	var pages_total = Math.ceil(items_total / page_items_per_page); 
	for (var i = 0; i <= pages_total + 3; i++) {
		var aItem = document.createElement("a");
		aItem.style.cursor = "pointer";
		aItem.style.display = "inline-block";
		aItem.style.textAlign = "center";
		aItem.style.margin = "5px";
		aItem.style.width = "35px";
		if (i === 0) {
			aItem.innerHTML = "<b>&lt;&lt;</b>";
			aItem.style.backgroundColor = "black";
			aItem.style.color = "white";
			aItem.onclick = function() {
				var previousPage = (Math.floor((currentPage(tableId) - 1) / pages_show) - 1) * pages_show + 1;
				updateTablePaging(tableId, Math.max(previousPage, 1), pages_show);			
				clickTablePaging(tableId, Math.max(previousPage, 1), page_items_per_page, command_callback, command_url, column_mapping);
			};						
		} else if (i === 1) {
			aItem.innerHTML = "<b>&lt;</b>";
			aItem.style.backgroundColor = "black";
			aItem.style.color = "white";
			aItem.onclick = function() {
				var previousPage = currentPage(tableId) - 1;
				updateTablePaging(tableId, Math.max(previousPage, 1), pages_show);			
				clickTablePaging(tableId, Math.max(previousPage, 1), page_items_per_page, command_callback, command_url, column_mapping);
			};
		} else if (i === pages_total + 2) {
			aItem.innerHTML = "<b>&gt;</b>";
			aItem.style.backgroundColor = "black";
			aItem.style.color = "white";
			aItem.onclick = function() {
				var nextPage = currentPage(tableId) + 1;				
				updateTablePaging(tableId, Math.min(nextPage, pages_total), pages_show);			
				clickTablePaging(tableId, Math.min(nextPage, pages_total), page_items_per_page, command_callback, command_url, column_mapping);
			};	
		} else if (i === pages_total + 3) {			
			aItem.innerHTML = "<b>&gt;&gt;</b>";
			aItem.style.backgroundColor = "black";
			aItem.style.color = "white";
			aItem.onclick = function() {
				var nextPage = (Math.floor((currentPage(tableId) - 1) / pages_show) + 1) * pages_show + 1;
				updateTablePaging(tableId, Math.min(nextPage, pages_total), pages_show);			
				clickTablePaging(tableId, Math.min(nextPage, pages_total), page_items_per_page, command_callback, command_url, column_mapping);
			};				
		} else {
			aItem.className = "pageno";
			aItem.innerHTML = i - 1;
			aItem.onclick = function() {
				updateTablePaging(tableId, +this.innerHTML, pages_show);			
				clickTablePaging(tableId, +this.innerHTML, page_items_per_page, command_callback, command_url, column_mapping);			
			};			
		}
		tblPaging.appendChild(aItem);
	}
	
	var tbl = document.getElementById(tableId);	
	
	if (tbl !== null) {	
		tbl.parentNode.appendChild(divItemsPerPage);
		tbl.parentNode.appendChild(tblPaging);		
		updateTablePaging(tableId, page_current, pages_show);
		clickTablePaging(tableId, page_current, page_items_per_page, command_callback, command_url, column_mapping);
		updateTableOrder(tableId, column_name, pages_show, page_items_per_page, command_callback, command_url, column_mapping, avoid_switch);
	}	
		
}

function refreshTable(tableId, items_total){
	var tblPagingId = "paging" + tableId;
	var tblPaging = document.getElementById(tblPagingId);
	var dataset = readDataset(tblPaging);
	var command_url = top.urlPrefix + "commands/paging?scope="+dataset.scope;

	dataset.items_total = items_total;
	
	writeDataset(tblPaging,dataset);	
	updateTablePaging(tableId, dataset.page_current, dataset.pages_show);
	clickTablePaging(tableId, dataset.page_current, dataset.page_items_per_page, dataset.command_callback, command_url, dataset.column_mapping);
}

function currentPage(tableId){
	var tblPaging = document.getElementById("paging" + tableId);			
	var pages = classSelector(tblPaging, "pageno");
	
	for (var i = 0; i < pages.length; i++) {
		if (pages[i].style.backgroundColor === "black") {
			return i + 1;
		}
	}			
	return 0;
}

function currentColumn(tableId){
	var tbl = document.getElementById(tableId);	
	var columns = tbl.getElementsByTagName("th");
	
	for (var i = 0; i < columns.length; i++) {
		var image = "" + columns[i].style.backgroundImage;
		if (image.indexOf("ft-headup.gif") > -1 || image.indexOf("ft-headdown.gif") > -1) {
			return columns[i];
		} 	
	}
	return columns[columns.length - 1];
}

function currentColumnLabel(tableId) {
	var column = currentColumn(tableId);
	if (column) {
		return column.innerHTML;
	} else {
		return "";
	}
}

function currentColumnOrder(tableId) {
	var column = currentColumn(tableId);
	if (column) {
		return column.className;
	} else {
		return "";
	}
}

function clickTablePaging(tableId, page_current, page_items_per_page, command_callback, command_url, column_mapping){
	var orderby = "";
	var columnLabel = currentColumnLabel(tableId);
	var columnOrder = currentColumnOrder(tableId);
	if (columnLabel !== "" && column_mapping[columnLabel] && (columnOrder === "asc" || columnOrder === "desc")) {
		orderby = column_mapping[columnLabel] + " " + columnOrder;
	}
	if (!Date.now) {
	    Date.now = function() {
	    	return new Date().getTime();
	    };
	}	
	var params = "&ts=" + Date.now() + "&items=" + page_items_per_page + "&tableId=" + tableId + "&page=" + page_current + "&callback=" + command_callback + "&orderBy=" + orderby;
	if (top.pipeCommands) {
		top.pipeCommands.queue.push(command_url + params);
	} else {		
		top.pipeCommands = {
				id: 0,
				queue: new Array(),
				next: function () {
					if (top.pipeCommands.queue.length > 0) {
						top.pipeCommand(top.document.getElementById("commandPipe"), top.pipeCommands.queue.shift());
						top.pipeCommands.id = setTimeout(top.pipeCommands.timeout, 60000);
					} else {
						clearTimeout(top.pipeCommands.id);
						top.pipeCommands = undefined;						
					}
				},
				timeout: function () {
					top.pipeCommands.next();
				}
		};
		top.pipeCommand(top.document.getElementById('commandPipe'), command_url + params);
	}
}

function pipeCommandFinished() {
	if (top.pipeCommands) {
		top.pipeCommands.next(); 	
	}
}

function updateTablePaging(tableId, page_current, pages_show){	
	var tblPaging = document.getElementById("paging" + tableId);		
		
	var pages = classSelector(tblPaging, "pageno");	

	var page_area = Math.ceil(page_current / pages_show) * pages_show;
	for (var i = 0; i < pages.length; i++) { 
		if (page_area > i && page_area < i + pages_show + 1) {
			pages[i].style.display = "inline-block";
		} else {
			pages[i].style.display = "none";
		} 
		if (page_current === i + 1) {
			pages[i].style.backgroundColor = "black";
			pages[i].style.color = "white";
		} else {
			pages[i].style.backgroundColor = "white";
			pages[i].style.color = "black";		
		}
	}			
}

function updateTable(tableId, rows_data, max_rows, cols_data, replacement){
	var tbl = document.getElementById(tableId);
	
	if (tbl == null)
		return;
	
	var lastRow = tbl.rows.length;
	
	var numberFields=max_rows;
	if (rows_data.length > max_rows)
		numberFields=rows_data.length;
	
	var lengthColsData = cols_data.length;
	var lengthRowsData = rows_data.length;
	var replacementArray = new Array();
	for (var j=0; j < lengthColsData; j++){
		if(!!replacement && (replacement instanceof Array) && !!replacement[j]){
			replacementArray.push(replacement[j]);
		} else if (!!replacement && !!!(replacement instanceof Array)){
			replacementArray.push(replacement);
		} else {
			replacementArray.push("\u00a0");
		}
	}
	
	var docFragment = null;
	
	//Header creation or replacement
	var tableHead = tbl.getElementsByTagName("thead");
	
	var width = new Array();
	
	if (tableHead.length==0){
		var myNewThead = document.createElement("thead");
		var row = document.createElement("tr");
		docFragment = document.createDocumentFragment();
		
		var currentHeaderRow = tbl.rows[0]; 
		for (var j=0; j < currentHeaderRow.cells.length; j++){
			cell = document.createElement("th");
			cell.className = currentHeaderRow.cells[j].className;
			cell.onclick = currentHeaderRow.cells[j].onclick;
			cell.onmouseover = currentHeaderRow.cells[j].onmouseover;
			cell.onmouseout = currentHeaderRow.cells[j].onmouseout;
			width[j] = currentHeaderRow.cells[j].width;
			if (!(typeof width[j]=== 'undefined')){
				cell.width = width[j];
			}
			
			var content = null;
			if (typeof currentHeaderRow.cells[j].innerText == "undefined"){
				content= currentHeaderRow.cells[j].textContent;
			} else {
				content= currentHeaderRow.cells[j].innerText;
			}
			
			var textNode = document.createTextNode(content.trim());
			cell.appendChild(textNode);
			row.appendChild(cell);
		}
		docFragment.appendChild(row);
		myNewThead.appendChild(docFragment);
		tbl.replaceChild(myNewThead, tbl.children[0]);
	}
	

	
	
	//Row creation or replacement
    var myNewtbody = document.createElement("tbody");
    docFragment = document.createDocumentFragment();
 	 
	for (var i=0; i < numberFields; i++){
		var row = document.createElement("tr");
		if (i%2==0){
			row.className="even";
		}else{
			row.className="odd";
		}
		
		var cell; 
		var textNode;
		
		
		
		for (var j=0; j < lengthColsData; j++){
			cell = document.createElement("td");
			cell.className = "sort_row_left";
			if (!(typeof width[j]=== 'undefined')){
				cell.width = width[j];
			}
			if (i < lengthRowsData){
				var colsData =cols_data[j];
				var rowsData = rows_data[i][colsData];
				if ((!!!rowsData || rowsData == "") &&
						"0" != rowsData && 
						(typeof rowsData == "string" || 0 != rowsData)){
					textNode = document.createTextNode(replacementArray[j]);
				}else{ 
					textNode = document.createTextNode(rowsData);
				}
			}else{
				textNode = document.createTextNode("\u00a0");
			}
			cell.appendChild(textNode);
			row.appendChild(cell);
		}

		cell = document.createElement("td");
		cell.className = "sort_row_left";
		cell.style.display="none";
        if (!!rows_data[i]){
        	textNode = document.createTextNode(i);
		} else {
			textNode = document.createTextNode("-1");
		}
        cell.appendChild(textNode);
        row.appendChild(cell);
        docFragment.appendChild(row);
	}
	myNewtbody.appendChild(docFragment);
	if(tbl.children.length <= 1){
		tbl.appendChild(myNewtbody);
	} else {
		var mytbody = tbl.children[1];
		tbl.replaceChild(myNewtbody, mytbody);
	}
	
}

function updateTableRow(tableId, rows_data, arrayIndex, cols_data, propertyName){
	var tbl = document.getElementById(tableId);
	if (tbl==null)
		return null;
	var lastRow = tbl.rows.length;
	var j=cols_data.indexOf(propertyName);

	for (var i=1; i < lastRow; i++){
		var cellNumbers = tbl.rows[i].cells.length;
		var cell = tbl.rows[i].cells[cellNumbers-1];
		if (cell.innerHTML==arrayIndex){
			var cellOperation = tbl.rows[i].cells[j];
			cellOperation.innerHTML = rows_data[arrayIndex][propertyName];
		}
	}
}

function getArrayIndexOfRow(tableId, rowId){
	var tbl = document.getElementById(tableId);
	
	if (tbl == null)
		return null;
	
	var length = tbl.rows[rowId].cells.length;
	return tbl.rows[rowId].cells[length-1].innerHTML;
}


function highlightRow(obj, inout, classHighlight, classOdd, classEven){
	//add one for header
	var row = obj.rowIndex+1;
	if(inout == "in"){
		obj.className=classHighlight;
	} else {
		if(inout == "out"){
			if(obj.isHighlighted == null || !obj.isHighlighted){
				if(row%2==0){
					obj.className=classEven;
				}else{
					obj.className=classOdd;					
				}
			}				
			
			obj.style.cursor='pointer'
		}
	}
}

function functionOnTable(tableId, itemList, functionReference){
	var tbl = document.getElementById(tableId);
	var itemListLength = itemList.length;
	
	if (tbl != null){
		var lastRow = tbl.rows.length;
		
		for (var i=1; i < lastRow; i++){
			if (i <=itemListLength){
				var row = tbl.rows[i];
				
				var createClickHandler = 
				function (row){
					return function(e) {
						var event = e || window.event;
						var j = row.rowIndex;
						functionReference(j, event);
					};
				}
				
				row.onclick = createClickHandler(row);
			
				row.onmouseover = new Function("highlightRow(this, 'in', 'highlight', 'odd', 'even')");
				row.onmouseout = new Function("highlightRow(this, 'out', 'highlight', 'odd', 'even')");
			}
		};
	}
}

function makeInputBox(tableId, columnNumber, inputName, size){
	var tbl = document.getElementById(tableId);
	
	if (tbl != null){
		var lastRow = tbl.rows.length;
		
		for (var i=1; i < lastRow; i++){
			var row = tbl.rows[i];
			var cell = row.cells[columnNumber];
			field = document.createElement('input');
			field.type = 'text';
			field.name = inputName+'#'+getArrayIndexOfRow(tableId, i);
			field.id = inputName+'#'+getArrayIndexOfRow(tableId, i);
			field.size=size;
			field.value = cell.innerHTML;
			field.setAttribute("nodb","true");
			cell.innerHTML = "";
			cell.appendChild(field);
		};
	}
}

function saveDrugModifications(force, next_handler, afterAction, opt_url, notSaveCallback){ 

	
	try { 
		var wnd = formWindow(); 				
		if (wnd!=null && (typeof wnd.document.forms == "object" || typeof wnd.document.forms == "function")) {
			try {
				var fields = isModifiedDrug(wnd.document.forms['crf']);
				if (fields.length>0) {
					confirmSubmit(
						force, 
						function() {
							if (top.formWindow().localPreSaveHandler != null){
								if (top.formWindow().localPreSaveHandler()){
									if (opt_url!=null) wnd.setOptionalUrl(opt_url);
									if (afterAction!=null) wnd.setAfterSubmitAction(afterAction);
									submitDrugRecord();
								} 
							} else {
								if (opt_url!=null) wnd.setOptionalUrl(opt_url);
								if (afterAction!=null) wnd.setAfterSubmitAction(afterAction);
								submitDrugRecord();
							};
						},
						notSaveCallback,
						null
					);
					return;
				}
			} catch (e) {
				if (wnd.getMainForm().elements.length>0) {
					alert(
						"Drug alert message\n"+
						"*******************************************\n"+
						"Warning!\n"+
						"JavaScript error occurred during checking the data.\n\n"+
						"Probably you try to navigate through the CRF too fast.\n\n"+
						"Please check the last saved data to ensure that\n"+
						"all data have been correctly stored in database.\n\n"+e
					);
				}
			}
		}
	} catch (e) {}
	if (null!=notSaveCallback) {
		try {
			if (document.all)
				notSaveCallback();
			else if (typeof notSaveCallback == "function")
				notSaveCallback();
		} catch (e) {}
	}
}


function formatDate(date, format){
	var monthInWord = new Array("January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December");
	
	var result = format+'';
	var dayInMonth = date.getDate();
	if (dayInMonth <= 9){
		dayInMonth = '0'+dayInMonth;
	}
	result = result.replace(/dd/,dayInMonth);
	result = result.replace(/yyyy/,date.getFullYear());
	result = result.replace(/MMMM+/,monthInWord[date.getMonth()]);
	result = result.replace(/MMM/,monthInWord[date.getMonth()].substring(0,3));
	
	var monthInYear = date.getMonth()+1;
	if (monthInYear <= 9){
		monthInYear = '0'+monthInYear;
	}
	result = result.replace(/MM/,monthInYear);
	return result;
};

function reformatDateFromDDMMYYYY(date, format){
	var monthInWord = new Array("January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December");
	var dayInMonth = date.substring(0,2);
	var monthAsNumber = date.substring(3,5);
	var fullYear = date.substring(6,10);
		
	var result = format+'';
	result = result.replace(/dd/,dayInMonth);
	result = result.replace(/yyyy/,fullYear);
	result = result.replace(/MMMM+/,monthInWord[monthAsNumber-1]);
	result = result.replace(/MMM/,monthInWord[monthAsNumber-1].substring(0,3));
	result = result.replace(/MM/,monthAsNumber);
	return result;
}

function reformatDateToDDMMYYYY (date, format){
	var monthInWord = new Array("January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December");
	
	if (date == null || date == ""){
		return "";
	}
	
	var positionMonth = format.search(/MMMM+/);
	var monthAsNumber = null;
	var monthAsName = null; 
	var overlapMonth = 0;
	
	if(positionMonth > -1){
		monthAsName = date.substring(positionMonth, positionMonth+3);
		for (var i=0; i< monthInWord.length; i++){
			if (monthInWord[i].substring(0,3)==monthAsName){
				if (i < 9){
					monthAsNumber = '0'+(i+1);
				} else {
					monthAsNumber = i+1;
				}
				overlapMonth = monthInWord[i].length-format.match(/MMMM+/)[0].length;
			}
		}
	}  else {
		positionMonth = format.search(/MMM/);
		if(positionMonth > -1){
			monthAsName = date.substring(positionMonth, positionMonth+3);
			for (var i=0; i< monthInWord.length; i++){
				if (monthInWord[i].substring(0,3)==monthAsName){
					if (i < 9){
						monthAsNumber = '0'+(i+1);
					} else {
						monthAsNumber = i+1;
					}
				}
			}
		} else {
			positionMonth = format.search(/MM/);
			monthAsNumber = date.substring(positionMonth, 2);
		} 
	}

	var positionDay = format.search(/dd/);
	var positionYear = format.search(/yyyy/);
	
	
	if (positionYear > positionMonth){
		positionYear += overlapMonth;
	} 
	
	if (positionDay > positionMonth){
		positionDay += overlapMonth;
	} 
	
	var fullYear = date.substring(positionYear, positionYear+4);
	var dayInMonth = date.substring(positionDay, positionDay+2);
	
	
	var result = 'dd-MM-yyyy';
	result = result.replace(/dd/,dayInMonth);
	result = result.replace(/yyyy/,fullYear);
	result = result.replace(/MM/,monthAsNumber);
	return result;
}

function convertJSONtoHiddenField(nameHiddenField, itemList, propertyListParameter, prefix){
	var divHiddenField = top.formWindow().document.getElementById(nameHiddenField);
	divHiddenField.innerHTML = "";
	if (prefix == null){
		prefix="";
	}
	
	var propertyList = new Array();
	
	for (var i =0; i < propertyListParameter.length; i++){
		if (propertyListParameter[i].toUpperCase() != "ID"){
			propertyList.push(propertyListParameter[i]);
		}
	}
	
	var prefixSeparated = "";
	if(prefix != ""){
		prefixSeparated = prefix +"#";
	} 
	
	if (itemList != null && itemList.length > 0){
		el = document.createElement("input");
		el.type="hidden";
		el.id = "PROPERTIES#"+prefix;
		el.name = "PROPERTIES#"+prefix;
		el.value = propertyList.join();
		divHiddenField.appendChild(el);
	}
	
	for (var i=0; i <itemList.length; i++){
		if(itemList[i]["id"] == ""){
			el = document.createElement("input");
			el.type="hidden";
			
			el.id = "CREATED#"+prefixSeparated+i+"#id";
			el.name = "CREATED#"+prefixSeparated+i+"#id";
			el.value = i;
			divHiddenField.appendChild(el);
			
			for (var j=0; j < propertyList.length; j++){
				el = document.createElement("input");
				el.type="hidden";

				el.id = "CREATED#"+prefixSeparated+i+"#"+propertyList[j];
				el.name = "CREATED#"+prefixSeparated+i+"#"+propertyList[j];
				el.value =itemList[i][propertyList[j]];
				divHiddenField.appendChild(el);
			}

		} else {
			el = document.createElement("input");
			el.type="hidden";

			
			
			el.id = "CHANGED#"+prefixSeparated+itemList[i]["id"]+"#id";
			el.name = "CHANGED#"+prefixSeparated+itemList[i]["id"]+"#id";
			el.value =itemList[i]["id"];
			divHiddenField.appendChild(el);
			
			for (var j=0; j < propertyList.length; j++){
				el = document.createElement("input");
				el.type="hidden";

				el.id = "CHANGED#"+prefixSeparated+itemList[i]["id"]+"#"+propertyList[j];
				el.name = "CHANGED#"+prefixSeparated+itemList[i]["id"]+"#"+propertyList[j];
				el.value =itemList[i][propertyList[j]];
				divHiddenField.appendChild(el);
			}
		
		}
	}
}

function convertDeletedJSONtoHiddenField(nameHiddenField, itemList, prefix){
	var divHiddenField = top.formWindow().document.getElementById(nameHiddenField);
	divHiddenField.innerHTML = "";
	if (prefix == null){
		prefix="";
	}
	
	var prefixSeparated = "";
	if(prefix != ""){
		prefixSeparated = prefix +"#";
	} 
	
	for (var i=0; i <itemList.length; i++){
		if(itemList[i]["id"] != ""){
			el = document.createElement("input");
			el.type="hidden";
			
			el.id = "DELETED#"+prefixSeparated+itemList[i]["id"]+"#id";
			el.name = "DELETED#"+prefixSeparated+itemList[i]["id"]+"#id";
			el.value = itemList[i]["id"];
			divHiddenField.appendChild(el);
		} 
	}
}

function getIndexByAttribute(itemList, attributeName, value){
	var i=0;
	var finished=false;
	while (i < itemList.length && !finished){
		if (attributeName != null){
			if (itemList[i][attributeName] == value){
				return i;
			} else {
				i++;	
			}
		} else {
			if (itemList[i] == value){
				return i;
			} else {
				i++;	
			}
		}
	}
	return -1;
}

function switchThrough (allItems, allItemsAttribute, includeList, includeItemsAttribute, currentValue){
	var i = getIndexByAttribute(allItems, allItemsAttribute, currentValue);
	var k = i;
	var nextValue = null;
	while (1 != 0){
		k++;
		if (k >= allItems.length){
			k=0;
		}
		if (allItemsAttribute != null){
			nextValue = allItems[k][allItemsAttribute];
		} else {
			nextValue = allItems[k];
		}
		
		if(includeList == null || getIndexByAttribute(includeList,includeItemsAttribute,nextValue) != -1){
			return k;
		} else if (k==i){
			return k;
		}
	}
}

function backgroundProcessOngoing(currprocess){
	if (null == currprocess || currprocess == "" || currprocess == "FINISHED" || currprocess.substr(0,9).toUpperCase() == "EXCEPTION"){
		return false;
	} else{
		return true;
	}
}

/*
 * Update a progress line and retrigger next progress update
 * 
 * @param divElementId element id of div section where progress is read from / written to
 * @param context Context for progress in JAVA background process
 * @param callbackIfFinished callback of function to call when progress states finished
 * @param disableEnableCallback callback of function to call when each run to update disable/enable values
 * @param forceRun true if progress should be updated unless field is initially filled
 * @param skipCallback allows to skip the callback, what might be important for an initial load
 */
function updateProgressSkippableWithExceptionHandling(divElementId, context, callbackIfFinished, callbackIfException, disableEnableCallback, forceRun, skipCallback){
	if (forceRun == null){
		forceRun = false;
	}
	
	var  currprocess = top.formWindow().document.getElementById(divElementId).innerHTML;
	if((!forceRun) && (!backgroundProcessOngoing(currprocess))){
		if ("FINISHED" == currprocess && callbackIfFinished != null){
			if(!skipCallback){
				callbackIfFinished();
			}
		} else if ( "EXCEPTION" == currprocess.substr(0,9).toUpperCase() && callbackIfException != null){
			if(!skipCallback){
				callbackIfException();
			}
		}
	} else {
		if (currprocess != ""){
			forceRun = false;
		}
		
		var url = "commands/update_progress?context="+context+"&divElementId="+divElementId;
		top.pipeCommand(top.document.getElementById('commandPipe'), url);
		
		setTimeout(function () {updateProgressSkippableWithExceptionHandling(divElementId, context, callbackIfFinished, callbackIfException, disableEnableCallback, forceRun, false)}, 2500);
	}
	if (disableEnableCallback != null){
		disableEnableCallback();
	}
}

/*
 * Update a progress line and retrigger next progress update
 * 
 * @param divElementId element id of div section where progress is read from / written to
 * @param context Context for progress in JAVA background process
 * @param callbackIfFinished callback of function to call when progress states finished
 * @param disableEnableCallback callback of function to call when each run to update disable/enable values
 * @param forceRun true if progress should be updated unless field is initially filled
 * @param skipCallback allows to skip the callback, what might be important for an initial load
 */
function updateProgressSkippable(divElementId, context, callbackIfFinished, disableEnableCallback, forceRun, skipCallback){
	updateProgressSkippableWithExceptionHandling(divElementId, context, callbackIfFinished, null, disableEnableCallback, forceRun, skipCallback);
}

/*
 * Same as updateProgress but always using the finisher callback 
 */
function updateProgress(divElementId, context, callbackIfFinished, disableEnableCallback, forceRun){
	updateProgressSkippable(divElementId, context, callbackIfFinished, disableEnableCallback, forceRun, false);
}

function stringifyJSONObject(object){
	if (object == null){
		return "";
	}
	var result = "{";
	for (var key in object) {
		  if (object.hasOwnProperty(key)) {
			  result += '"'+key+'" : "'+object[key]+'",'
		  }
	}
	if (result == "{"){
		return "";
	}
	result = result.substring(0,result.length-1)+"}";
	return result;
}

function transferSelectBoxEntries(form, inputId, outputId){
	var outputSelector = form.elements[outputId];
	for (var i=outputSelector.options.length-1; i>=0; --i){
		outputSelector.remove(i);
    }
	
	var inputSelector = form.elements[inputId];
	for (var i=inputSelector.options.length-1; i>=0; --i){
		var inputOption = inputSelector.options[i];
		var outputOption = new Option(inputOption.text, inputOption.value, inputOption.defaultSelected, inputOption.selected);
		outputSelector.add(outputOption);
		inputSelector.remove(i);
    }
}


function EditFieldState(tableName, operation){
	this.currentIndex = -1;
	this.rowId = "";
	this.tableName = tableName;
	this.operation = operation ;
	this.updateEditField = function(){};
	this.items = {};
	
	this.controlRowMarker = function(newRowId){
		var tbl = document.getElementById(this.tableName);
		var oldRowId = this.rowId;
		if (oldRowId != ""){
		   var row = tbl.rows[oldRowId];
		   row.isHighlighted=false;
		   highlightRow(row, 'out', 'highlight', 'odd', 'even');
		   this.rowId='';
	   }
		
	   if (newRowId != ""){
		  var row = tbl.rows[newRowId];
		   row.isHighlighted=true;
		   highlightRow(row, 'out', 'highlight', 'odd', 'even');
		   this.rowId=newRowId;
		}
	}
	
	this.loadCurrentItem = function loadCurrentItem(rowId){
		this.currentIndex = getArrayIndexOfRow(this.tableName, rowId);
		this.controlRowMarker(rowId);
		document.getElementById("operation").value = this.operation;
		this.updateEditField();
	}
	
	this.createNew = function(){
		this.currentIndex=-1;
		controlRowMarker('');
		document.getElementById("operation").value =  this.operation;
		this.updateEditField();
	}
	
	return this;
}